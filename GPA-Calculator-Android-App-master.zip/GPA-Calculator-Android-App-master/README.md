# GPA-Calculator-Android-App

This is an Android app to calculate GPA of a student. Students can enter their grades for 5 courses. The app computes GPA of the students and shows on the screen. 
The app displays a red background if GPA less than 60, Yellow for 61-79, and Green for 80 to 100.

![App_Snapshot_1_Icon](https://user-images.githubusercontent.com/72088607/222605168-f9408cd6-324e-4125-874a-2202ddc8c018.PNG)
![App_Snapshot_2_Home](https://user-images.githubusercontent.com/72088607/222605171-172c86d2-a16c-4bab-a32a-3299c8a1d995.PNG)
![App_Snapshot_5_GPA_Green](https://user-images.githubusercontent.com/72088607/222605172-90086f10-caaa-4043-baa6-a1d44a63306a.PNG)
![App_Snapshot_6_GPA_Yellow](https://user-images.githubusercontent.com/72088607/222605174-ff99398f-51c7-41ff-aa31-f254aed57e94.PNG)
